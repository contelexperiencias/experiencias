

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-sm-10">
        <h4 class="text-center">Producto de la Categoria: <?php echo e($categorias[0]->nombre); ?></h4>
            <a href="<?php echo e(route('producto.index')); ?>" class="btn-sm btn-success">Regresar</a>

            <?php echo Form::open(['route'=>['producto.update',$producto],'method'=>'PUT','files'=>true]); ?>


            <div class="jumbotron">
            
        
         
               
           
                <div class="form-group">
                    <label for="title">INGRESE TITLE</label>
                    <?php echo Form::text('title',$producto->title,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>
                <div class="form-group">
                    <label for="description">INGRESE description</label>
                    <?php echo Form::textarea('description',$producto->description,['class'=>'form-control','maxlength'=>'67','rows'=>'3']); ?>

                </div>

                <div class="form-group">
                    <label for="nombre">INGRESE NOMBRE</label>
                    <?php echo Form::text('nombre',$producto->nombre,['class'=>'form-control','maxlength'=>'100']); ?>

                </div>

                <div class="form-group">
                    <label for="descripcion">INGRESE DESCRIPCIÓN</label>
                    <?php echo Form::textarea('descripcion',$producto->descripcion,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="nombre">INGRESE TARIFA</label>
                    <?php echo Form::text('tarifa',$producto->tarifa,['class'=>'form-control','maxlength'=>'67']); ?>

                </div> 
 
             <div class=" row form-group col-sm-12">
              <div class="col-sm-6">
               <span class="anchor"><strong>DESTINOS</strong></span>
               
                   
               <?php $__empty_1 = true; $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>   
               <?php $activochk=''; ?> 
               <ul class="items">                 
                    <?php $__empty_2 = true; $__currentLoopData = $relProductoDestino; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>            
                
                        <?php if($item->id == $it->destino_id): ?>
                        <?php $activochk='checked'; ?>                   
                        
                       
                       
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                    <?php endif; ?>
                   
                    <li> <?php echo Form::checkbox($item->slug, $item->id, $activochk); ?><label for="<?php echo e($item->nombre); ?>"> <?php echo e($item->nombre); ?></label></li> 


          

              
                    
                   
                </ul>                    
          
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                       
               <?php endif; ?>

                 
              </div> 
              <div class="col-sm-6">
              <span class="anchor"><strong>¿Con Quién?</strong></span>
              <!-- <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="familia" id="familia" <?php echo e(($producto->familia == 1) ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="familia">
                                        <?php echo e(__('familia')); ?>

                                    </label>
                </div> -->
                <ul class="items">
              
                
                    <li> <?php echo Form::checkbox('Familia', $producto->familia, ($producto->familia == 1) ? 'checked' : '' ); ?><label for="familia"> En familia </label></li>
                    <li> <?php echo Form::checkbox('Pareja', $producto->pareja, ($producto->pareja == 1) ? 'checked' : '' ); ?><label for="pareja">En Pareja</label></li>
                    <li> <?php echo Form::checkbox('Grupo',  $producto->grupo, ($producto->grupo == 1) ? 'checked' : ''); ?><label for="grupo">Grupo</label></li>
                    <li> <?php echo Form::checkbox('Solo',  $producto->solo, ($producto->solo == 1) ? 'checked' : ''); ?><label for="solo">Solo</label></li>
                   
                </ul> 
              </div>                           
            </div> 

                <div class="form-group">
                    <label for="orden">INGRESE ORDEN</label>
                    <?php echo Form::text('orden',$producto->orden,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="urlfoto">IMAGEN (400 x 386 px)</label> <br>
                    <img src="/img/producto/<?php echo e($producto->urlfoto); ?>?<?php echo e(rand(22,99999)); ?>">
                    <?php echo Form::file('urlfoto'); ?>

                </div>
               <div class="row">
               
               <div class="form-group col-sm-3">
                    <label for="urlfoto">IMAGEN (400 x 386 px)</label> <br>
                    <img class="thumbnail w-100" src="/img/producto/<?php echo e($producto->urlfoto2); ?>?<?php echo e(rand(22,99999)); ?>">
                    <?php echo Form::file('urlfoto2'); ?>

                </div>
                <div class="form-group col-sm-3">
                    <label for="urlfoto">IMAGEN (400 x 386 px)</label> <br>
                    <img class="thumbnail w-100" src="/img/producto/<?php echo e($producto->urlfoto3); ?>?<?php echo e(rand(22,99999)); ?>">
                    <?php echo Form::file('urlfoto3'); ?>

                </div>
                <div class="form-group col-sm-3">
                    <label for="urlfoto">IMAGEN (400 x 386 px)</label> <br>
                    <img class="thumbnail w-100" src="/img/producto/<?php echo e($producto->urlfoto4); ?>?<?php echo e(rand(22,99999)); ?>">
                    <?php echo Form::file('urlfoto4'); ?>

                </div>
                <div class="form-group col-sm-3">
                    <label for="urlfoto">IMAGEN (400 x 386 px)</label> <br>
                    <img class="thumbnail w-100" src="/img/producto/<?php echo e($producto->urlfoto5); ?>?<?php echo e(rand(22,99999)); ?>">
                    <?php echo Form::file('urlfoto5'); ?>

                </div>
               
               </div>
            </div>
            
            <?php echo Form::submit('GUARDAR',['class'=>'btn btn-success']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
   CKEDITOR.replace( 'descripcion' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Documents\GitHub\experiencias\experiencias\resources\views/admin/producto/edit.blade.php ENDPATH**/ ?>