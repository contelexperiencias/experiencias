
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-sm-10">
        
        <h4 class="text-center">NUEVO Producto para la Categoria: <?php echo e($categorias[0]->nombre); ?></h4>
            <a href="<?php echo e(route('producto.index')); ?>" class="btn-sm btn-success">Regresar</a>

            <?php echo Form::open(['route'=>['producto.store'],'method'=>'POST','files'=>true]); ?>

           

           
           
            <div class="jumbotron">
             <div class="form-group">
                <label for="title">INGRESE TITLE</label>
                    <?php echo Form::text('title',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>        
               

                <div class="form-group">
                    <label for="nombre">INGRESE NOMBRE DEL PAQUETE</label>
                    <?php echo Form::text('nombre',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div> 
                 <div class="form-group">
                    <label for="description">INGRESE DESCRIPTION</label>
                    <?php echo Form::textarea('description',null ,['class'=>'form-control','maxlength'=>'155','rows'=>'3']); ?>

                </div>
                <div class="form-group" >
                    <label for="descripcion">INGRESE DESCRIPCIÓN</label>
                    <?php echo Form::textarea('descripcion',NULL ,['class'=>'form-control']); ?>

                </div>

                
                <div class="form-group">
                    <label for="nombre">INGRESE TARIFA</label>
                    <?php echo Form::text('tarifa',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div> 
                <div class=" row form-group col-sm-12">
              <div class="col-sm-6">
               <span class="anchor"><strong>DESTINOS</strong></span>
               <?php $__empty_1 = true; $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <ul class="items">
                    <li> <?php echo Form::checkbox($item->slug, $item->id); ?><label for="<?php echo e($item->nombre); ?>"> <?php echo e($item->nombre); ?></label></li>                   
                </ul>                              
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>                       
               <?php endif; ?> 
              </div> 
              <div class="col-sm-6">
              <span class="anchor"><strong>¿Con Quién?</strong></span>
                <ul class="items">
                    <li> <?php echo Form::checkbox('Familia', '1'); ?><label for="Cancun"> En familia </label></li>
                    <li> <?php echo Form::checkbox('Pareja',  '1'); ?><label for="Riviera">En Pareja</label></li>
                    <li> <?php echo Form::checkbox('Grupo',  '1'); ?><label for="Tulum">Grupo</label></li>
                    <li> <?php echo Form::checkbox('Solo',  '1'); ?><label for="Holbox">Solo</label></li>
                   
                </ul> 
              </div>                           
            </div> 



                <div class="form-group">
                    <label for="orden">INGRESE ORDEN</label>
                    <?php echo Form::text('orden',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="urlfoto">IMAGEN</label> <br>
                    <img src="/img/producto/foto.jpg">
                    <?php echo Form::file('urlfoto'); ?>

                </div>

            </div>
            <?php echo Form::submit('GUARDAR',['class'=>'btn btn-success']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
    CKEDITOR.replace( 'descripcion' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Documents\GitHub\experiencias\experiencias\resources\views/admin/producto/create.blade.php ENDPATH**/ ?>