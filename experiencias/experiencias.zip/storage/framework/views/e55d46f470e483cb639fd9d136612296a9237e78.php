
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-sm-10">
        
        <h4 class="text-center">NUEVO DESTINO</h4>
            <a href="<?php echo e(route('destino.index')); ?>" class="btn-sm btn-success">Regresar</a>

            <?php echo Form::open(['route'=>['destino.store'],'method'=>'POST','files'=>true]); ?>

           

           
           
            <div class="jumbotron">
             <div class="form-group">
                <label for="title">INGRESE TITLE</label>
                    <?php echo Form::text('title',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>        
               

                <div class="form-group">
                    <label for="nombre">INGRESE NOMBRE DEL DESTINO</label>
                    <?php echo Form::text('nombre',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div> 
            </div>
            <?php echo Form::submit('GUARDAR',['class'=>'btn btn-success']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<script>
    CKEDITOR.replace( 'descripcion' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Documents\GitHub\experiencias\experiencias\resources\views/admin/destino/create.blade.php ENDPATH**/ ?>