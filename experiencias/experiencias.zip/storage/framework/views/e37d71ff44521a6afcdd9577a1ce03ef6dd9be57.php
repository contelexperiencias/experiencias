

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('admin.submenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="col-sm-10"> 
        <h4 class="text-center">CREAR CATEGORÍA</h4>
        <?php echo Form::open(['route'=>['categoria.store'],'method'=>'POST','files'=>true]); ?>

        
        <a href="<?php echo e(route('categoria.index')); ?>" class="btn-sm btn-success">Regresar</a>
            <div class="jumbotron">
                <div class="form-group">
                    <label for="title">INGRESE TITLE</label>
                    <?php echo Form::text('title',null,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>
                <div class="form-group">
                    <label for="description">INGRESE DESCRIPTION</label>
                    <?php echo Form::text('description',null ,['class'=>'form-control','maxlength'=>'155','rows'=>'3']); ?>

                </div>

                <div class="form-group">
                    <label for="nombre">INGRESE NOMBRE</label>
                    <?php echo Form::text('nombre',null ,['class'=>'form-control','maxlength'=>'67']); ?>

                </div>

                <div class="form-group">
                    <label for="descripcion">INGRESE DESCRIPCIÓN</label>
                    <?php echo Form::textarea('descripcion',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="orden">INGRESE ORDEN</label>
                    <?php echo Form::text('orden',null ,['class'=>'form-control']); ?>

                </div>

                <div class="form-group">
                    <label for="urlfoto">IMAGEN</label> <br>
                    <img src="/img/categoria/foto.jpg">
                    <?php echo Form::file('urlfoto'); ?>

                </div>
                <?php echo Form::submit('Guardar',['class'=>'btn btn-success']); ?>

                <?php echo Form::close(); ?>


            </div>
           
        </div>
    </div>
</div>
<script>
    CKEDITOR.replace( 'descripcion' );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\developer\Documents\GitHub\experiencias\experiencias\resources\views/admin/categorias/create.blade.php ENDPATH**/ ?>