<div class="col sm 2">
<div class="list-group"   id="list-tab" role="tablist">
<!-- <ul class="list-group">
<li class="list-group-item list-group-item-action"> -->
 <a href="/admin/configuracion" class="list-group-item list-group-item-action btn btn-primary"  role="tab">configuración</a>
<!-- </li>
<li class="list-group-item list-group-item-action"> -->
 <a href="/admin/categoria" class="list-group-item list-group-item-action btn btn-primary" role="tab">Categorias</a>
 <a href="/admin/destino" class="list-group-item list-group-item-action btn btn-primary" role="tab">Destinos</a>
 <a href="/admin/post" class="list-group-item list-group-item-action btn btn-primary" role="tab">Blog</a>
 <a href="/admin/carrusel" class="list-group-item list-group-item-action btn btn-primary" role="tab">Carrusel</a>
 <a href="/admin/empresa" class="list-group-item list-group-item-action btn btn-primary" role="tab">Empresa</a>
 <a href="/admin/curiosidad" class="list-group-item list-group-item-action btn btn-primary" role="tab">Curiosidades</a>
<!-- </li>
</ul> -->
</div>
</div>

<?php /**PATH C:\Users\developer\Documents\GitHub\experiencias\experiencias\resources\views/admin/submenu.blade.php ENDPATH**/ ?>